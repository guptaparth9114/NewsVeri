from dotenv import load_dotenv
import os

load_dotenv()

NEWSAPI_KEY = os.getenv('NEWSAPI_KEY')
MONGODB_URI = os.getenv('MONGODB_URI')
JWT_SECRET = os.getenv('JWT_SECRET')
JWT_ALGORITHM = 'HS256'
CACHE_TTL = 600  # 10 minutes in seconds