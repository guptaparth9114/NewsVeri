from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from transformers import pipeline
import torch

# Initialize models
sentiment_analyzer = SentimentIntensityAnalyzer()
fake_news_detector = pipeline("text-classification", 
                            model="facebook/bart-large-mnli",
                            device=0 if torch.cuda.is_available() else -1)

def analyze_sentiment(text):
    scores = sentiment_analyzer.polarity_scores(text)
    if scores['compound'] >= 0.05:
        return 'positive'
    elif scores['compound'] <= -0.05:
        return 'negative'
    else:
        return 'neutral'

def detect_fake_news(text):
    result = fake_news_detector(text, 
                              candidate_labels=["reliable", "unreliable", "fake news"])
    return {
        'score': result['scores'][0],
        'label': result['labels'][0]
    }