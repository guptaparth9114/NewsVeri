from pymongo import MongoClient
from config import MONGODB_URI
from datetime import datetime

client = MongoClient(MONGODB_URI)
db = client.news_db

class NewsCache:
    @staticmethod
    def get_cached_news(query):
        cache = db.news_cache.find_one({
            'query': query,
            'timestamp': {'$gt': datetime.now().timestamp() - 600}  # 10 minutes
        })
        return cache['articles'] if cache else None

    @staticmethod
    def cache_news(query, articles):
        db.news_cache.update_one(
            {'query': query},
            {
                '$set': {
                    'articles': articles,
                    'timestamp': datetime.now().timestamp()
                }
            },
            upsert=True
        )

class User:
    @staticmethod
    def create(email, password_hash, name):
        return db.users.insert_one({
            'email': email,
            'password': password_hash,
            'name': name,
            'is_premium': False,
            'created_at': datetime.now()
        }).inserted_id

    @staticmethod
    def get_by_email(email):
        return db.users.find_one({'email': email})

    @staticmethod
    def update_premium_status(user_id, is_premium):
        db.users.update_one(
            {'_id': user_id},
            {'$set': {'is_premium': is_premium}}
        )