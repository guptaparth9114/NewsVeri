from flask import Flask, request, jsonify
from flask_cors import CORS
from newsapi import NewsApiClient
from datetime import datetime
import jwt
import bcrypt
from config import *
from models import NewsCache, User
from ml_models import analyze_sentiment, detect_fake_news

app = Flask(__name__)
CORS(app)
newsapi = NewsApiClient(api_key=NEWSAPI_KEY)

def get_token_data(token):
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except:
        return None

@app.route('/api/news/trending', methods=['GET'])
def get_trending_news():
    cached_news = NewsCache.get_cached_news('trending')
    if cached_news:
        return jsonify(cached_news)

    news = newsapi.get_top_headlines(language='en', country='us')
    
    # Process articles with sentiment analysis
    processed_articles = []
    for article in news['articles']:
        sentiment = analyze_sentiment(article['title'] + ' ' + article['description'])
        processed_article = {
            **article,
            'sentiment': sentiment
        }
        processed_articles.append(processed_article)
    
    NewsCache.cache_news('trending', processed_articles)
    return jsonify(processed_articles)

@app.route('/api/news/search', methods=['POST'])
def search_news():
    data = request.json
    query = data.get('query')
    
    cached_news = NewsCache.get_cached_news(query)
    if cached_news:
        return jsonify(cached_news)

    news = newsapi.get_everything(q=query, language='en', sort_by='relevancy')
    
    # Process articles
    processed_articles = []
    for article in news['articles']:
        sentiment = analyze_sentiment(article['title'] + ' ' + article['description'])
        processed_article = {
            **article,
            'sentiment': sentiment
        }
        
        # Add fake news detection for premium users
        token = request.headers.get('Authorization')
        if token:
            token_data = get_token_data(token)
            if token_data and token_data.get('is_premium'):
                fake_news_analysis = detect_fake_news(
                    article['title'] + ' ' + article['description']
                )
                processed_article['fake_news_analysis'] = fake_news_analysis
        
        processed_articles.append(processed_article)
    
    NewsCache.cache_news(query, processed_articles)
    return jsonify(processed_articles)

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    name = data.get('name')
    
    if User.get_by_email(email):
        return jsonify({'error': 'Email already exists'}), 400
    
    password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    user_id = User.create(email, password_hash, name)
    
    token = jwt.encode(
        {'user_id': str(user_id), 'is_premium': False},
        JWT_SECRET,
        algorithm=JWT_ALGORITHM
    )
    
    return jsonify({'token': token})

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    
    user = User.get_by_email(email)
    if not user or not bcrypt.checkpw(password.encode('utf-8'), user['password']):
        return jsonify({'error': 'Invalid credentials'}), 401
    
    token = jwt.encode(
        {'user_id': str(user['_id']), 'is_premium': user['is_premium']},
        JWT_SECRET,
        algorithm=JWT_ALGORITHM
    )
    
    return jsonify({'token': token, 'is_premium': user['is_premium']})

@app.route('/api/payments/upgrade', methods=['POST'])
def upgrade_to_premium():
    token = request.headers.get('Authorization')
    if not token:
        return jsonify({'error': 'Unauthorized'}), 401
    
    token_data = get_token_data(token)
    if not token_data:
        return jsonify({'error': 'Invalid token'}), 401
    
    # Process payment (integrate with Stripe or other payment provider)
    # For now, just update the user's premium status
    User.update_premium_status(token_data['user_id'], True)
    
    new_token = jwt.encode(
        {'user_id': token_data['user_id'], 'is_premium': True},
        JWT_SECRET,
        algorithm=JWT_ALGORITHM
    )
    
    return jsonify({'token': new_token, 'is_premium': True})

if __name__ == '__main__':
    app.run(debug=True, port=5000)