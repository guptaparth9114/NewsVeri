import React from 'react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-[#0A2463] text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-serif text-xl font-bold mb-4">InSight News</h3>
            <p className="text-gray-300 text-sm">
              Delivering unbiased and insightful news coverage from around the globe.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Categories</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><a href="#politics" className="hover:text-white transition-colors">Politics</a></li>
              <li><a href="#business" className="hover:text-white transition-colors">Business</a></li>
              <li><a href="#technology" className="hover:text-white transition-colors">Technology</a></li>
              <li><a href="#sports" className="hover:text-white transition-colors">Sports</a></li>
              <li><a href="#entertainment" className="hover:text-white transition-colors">Entertainment</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Company</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><a href="#about" className="hover:text-white transition-colors">About Us</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
              <li><a href="#careers" className="hover:text-white transition-colors">Careers</a></li>
              <li><a href="#advertise" className="hover:text-white transition-colors">Advertise</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Legal</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><a href="#terms" className="hover:text-white transition-colors">Terms of Use</a></li>
              <li><a href="#privacy" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#cookies" className="hover:text-white transition-colors">Cookie Policy</a></li>
              <li><a href="#accessibility" className="hover:text-white transition-colors">Accessibility</a></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-700 text-sm text-gray-400 flex flex-col md:flex-row justify-between items-center">
          <p>&copy; {currentYear} InSight News. All rights reserved.</p>
          <div className="mt-4 md:mt-0 flex space-x-4">
            <a href="#twitter" className="hover:text-white transition-colors">Twitter</a>
            <a href="#facebook" className="hover:text-white transition-colors">Facebook</a>
            <a href="#instagram" className="hover:text-white transition-colors">Instagram</a>
            <a href="#linkedin" className="hover:text-white transition-colors">LinkedIn</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;