import React, { useState } from 'react';
import Header from './Header';
import Sidebar from './Sidebar';
import Footer from './Footer';
import LoginModal from '../Auth/LoginModal';
import { Category } from '../../types';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  
  const categories: Category[] = [
    'politics', 
    'business', 
    'technology', 
    'sports', 
    'entertainment', 
    'health', 
    'science'
  ];
  
  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);
  const openLoginModal = () => setIsLoginModalOpen(true);
  const closeLoginModal = () => setIsLoginModalOpen(false);

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header 
        toggleSidebar={toggleSidebar} 
        openLoginModal={openLoginModal} 
      />
      
      <div className="flex flex-1">
        <Sidebar 
          isOpen={isSidebarOpen} 
          onClose={() => setIsSidebarOpen(false)} 
          openLoginModal={openLoginModal}
          categories={categories}
        />
        
        <main className="flex-1">
          {children}
        </main>
      </div>
      
      <Footer />
      
      {isLoginModalOpen && <LoginModal onClose={closeLoginModal} />}
    </div>
  );
};

export default Layout;