import { Article, Category } from '../types';

// Helper function to generate random sentiment
const getRandomSentiment = (): 'positive' | 'negative' | 'neutral' => {
  const sentiments: ('positive' | 'negative' | 'neutral')[] = ['positive', 'negative', 'neutral'];
  return sentiments[Math.floor(Math.random() * sentiments.length)];
};

// Create mock articles for each category
const createArticlesForCategory = (category: Category, count: number): Article[] => {
  return Array.from({ length: count }, (_, i) => ({
    id: `${category}-${i + 1}`,
    title: `${category.charAt(0).toUpperCase() + category.slice(1)} Headline ${i + 1}`,
    summary: `This is a summary for the ${category} article ${i + 1}. It provides a brief overview of the content.`,
    content: `This is the full content of the ${category} article ${i + 1}. It contains detailed information about the news story.`,
    author: `Author ${i + 1}`,
    date: new Date(Date.now() - i * 86400000).toISOString().split('T')[0], // Recent dates
    category,
    imageUrl: `https://source.unsplash.com/random/800x600?${category}&sig=${i}`,
    sentiment: getRandomSentiment(),
    isTrending: i < 2, // Make first two articles trending
  }));
};

// Generate mock articles for all categories
export const articles: Article[] = [
  ...createArticlesForCategory('politics', 10),
  ...createArticlesForCategory('business', 8),
  ...createArticlesForCategory('technology', 8),
  ...createArticlesForCategory('sports', 6),
  ...createArticlesForCategory('entertainment', 6),
  ...createArticlesForCategory('health', 5),
  ...createArticlesForCategory('science', 5),
];

// Get trending articles
export const trendingArticles = articles.filter(article => article.isTrending);

// Get articles by category
export const getArticlesByCategory = (category: Category): Article[] => {
  return articles.filter(article => article.category === category);
};

// Get article by ID
export const getArticleById = (id: string): Article | undefined => {
  return articles.find(article => article.id === id);
};