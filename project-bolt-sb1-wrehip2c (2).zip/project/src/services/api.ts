import axios from 'axios';
import { useAuthStore } from '../store/useAuthStore';

const API_URL = 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
});

api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token;
  if (token) {
    config.headers.Authorization = token;
  }
  return config;
});

export const getTrendingNews = async () => {
  const response = await api.get('/news/trending');
  return response.data;
};

export const searchNews = async (query: string) => {
  const response = await api.post('/news/search', { query });
  return response.data;
};

export const register = async (email: string, password: string, name: string) => {
  const response = await api.post('/auth/register', { email, password, name });
  return response.data;
};

export const login = async (email: string, password: string) => {
  const response = await api.post('/auth/login', { email, password });
  return response.data;
};

export const upgradeToPremium = async () => {
  const response = await api.post('/payments/upgrade');
  return response.data;
};