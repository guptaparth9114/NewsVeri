import { create } from 'zustand';
import { jwtDecode } from 'jwt-decode';

interface AuthState {
  token: string | null;
  isPremium: boolean;
  setAuth: (token: string) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  token: null,
  isPremium: false,
  setAuth: (token) => {
    const decoded = jwtDecode(token);
    set({ 
      token, 
      isPremium: decoded.is_premium 
    });
  },
  logout: () => set({ token: null, isPremium: false }),
}));