/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        serif: ['Merriweather', 'Georgia', 'serif'],
        sans: ['Open Sans', 'system-ui', 'sans-serif'],
      },
      colors: {
        primary: {
          50: '#e6ebf5',
          100: '#ccd7eb',
          200: '#99afd7',
          300: '#6687c3',
          400: '#335faf',
          500: '#0A2463',
          600: '#091d4f',
          700: '#07163b',
          800: '#050e28',
          900: '#020714',
        },
      },
      animation: {
        pulse: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        pulse: {
          '0%, 100%': { opacity: 1 },
          '50%': { opacity: 0.5 },
        },
      },
    },
  },
  plugins: [],
};