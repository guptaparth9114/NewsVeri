import React, { useState } from 'react';
import { X, CreditCard, Check } from 'lucide-react';

interface PaymentModalProps {
  onClose: () => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ onClose }) => {
  const [plan, setPlan] = useState<'monthly' | 'yearly'>('monthly');
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  
  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || '';
    const parts = [];
    
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    
    if (parts.length) {
      return parts.join(' ');
    }
    return value;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock payment processing
    console.log('Payment', { plan, cardNumber, cardName, expiryDate, cvv });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold text-gray-900">
            Subscribe to Premium
          </h2>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 focus:outline-none"
            aria-label="Close"
          >
            <X size={20} />
          </button>
        </div>
        
        <div className="p-6">
          <div className="mb-6">
            <p className="text-gray-600 mb-4">
              Get unlimited access to all articles, including fake news detection and personalized content.
            </p>
            
            <div className="flex bg-gray-100 rounded-lg p-1 mb-6">
              <button
                className={`flex-1 py-2 text-center rounded-md ${
                  plan === 'monthly' ? 'bg-white shadow-sm' : 'text-gray-700'
                }`}
                onClick={() => setPlan('monthly')}
              >
                Monthly
              </button>
              <button
                className={`flex-1 py-2 text-center rounded-md ${
                  plan === 'yearly' ? 'bg-white shadow-sm' : 'text-gray-700'
                }`}
                onClick={() => setPlan('yearly')}
              >
                Yearly (Save 20%)
              </button>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-medium text-gray-900">
                  {plan === 'monthly' ? 'Monthly Plan' : 'Annual Plan'}
                </h3>
                <span className="font-semibold text-[#0A2463]">
                  {plan === 'monthly' ? '$9.99/month' : '$95.88/year'}
                </span>
              </div>
              
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-start">
                  <Check size={16} className="text-green-500 mr-2 mt-0.5" />
                  <span>Unlimited article access</span>
                </li>
                <li className="flex items-start">
                  <Check size={16} className="text-green-500 mr-2 mt-0.5" />
                  <span>Fake news detection</span>
                </li>
                <li className="flex items-start">
                  <Check size={16} className="text-green-500 mr-2 mt-0.5" />
                  <span>Personalized news feed</span>
                </li>
                <li className="flex items-start">
                  <Check size={16} className="text-green-500 mr-2 mt-0.5" />
                  <span>Ad-free experience</span>
                </li>
              </ul>
            </div>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="card-number" className="block text-sm font-medium text-gray-700 mb-1">
                Card Number
              </label>
              <div className="relative">
                <input
                  type="text"
                  id="card-number"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="1234 5678 9012 3456"
                  maxLength={19}
                  required
                />
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <CreditCard size={18} className="text-gray-400" />
                </div>
              </div>
            </div>
            
            <div>
              <label htmlFor="card-name" className="block text-sm font-medium text-gray-700 mb-1">
                Cardholder Name
              </label>
              <input
                type="text"
                id="card-name"
                value={cardName}
                onChange={(e) => setCardName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="John Doe"
                required
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="expiry" className="block text-sm font-medium text-gray-700 mb-1">
                  Expiry Date
                </label>
                <input
                  type="text"
                  id="expiry"
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="MM/YY"
                  maxLength={5}
                  required
                />
              </div>
              
              <div>
                <label htmlFor="cvv" className="block text-sm font-medium text-gray-700 mb-1">
                  CVV
                </label>
                <input
                  type="text"
                  id="cvv"
                  value={cvv}
                  onChange={(e) => setCvv(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="123"
                  maxLength={3}
                  required
                />
              </div>
            </div>
            
            <button
              type="submit"
              className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-white bg-[#0A2463] hover:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
            >
              Subscribe Now
            </button>
            
            <p className="text-xs text-gray-500 text-center mt-4">
              By subscribing, you agree to our terms and conditions. You can cancel your subscription at any time.
            </p>
          </form>
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;