import React from 'react';
import { Category } from '../../types';

interface CategoryNavProps {
  categories: Category[];
}

const CategoryNav: React.FC<CategoryNavProps> = ({ categories }) => {
  return (
    <nav className="border-t border-b border-gray-200 bg-gray-50">
      <div className="container mx-auto px-4 overflow-x-auto">
        <ul className="flex space-x-6 py-3 whitespace-nowrap">
          <li>
            <a 
              href="#home" 
              className="text-sm font-medium text-[#0A2463] hover:text-blue-700 transition-colors"
            >
              Home
            </a>
          </li>
          {categories.map((category) => (
            <li key={category}>
              <a 
                href={`#${category}`} 
                className="text-sm font-medium text-gray-700 hover:text-[#0A2463] transition-colors capitalize"
              >
                {category}
              </a>
            </li>
          ))}
          <li>
            <a 
              href="#opinion" 
              className="text-sm font-medium text-gray-700 hover:text-[#0A2463] transition-colors"
            >
              Opinion
            </a>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default CategoryNav;