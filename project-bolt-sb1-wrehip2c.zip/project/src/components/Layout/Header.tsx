import React, { useState } from 'react';
import { Menu, Search, User, X } from 'lucide-react';
import { Category } from '../../types';
import CategoryNav from './CategoryNav';

interface HeaderProps {
  toggleSidebar: () => void;
  openLoginModal: () => void;
}

const Header: React.FC<HeaderProps> = ({ toggleSidebar, openLoginModal }) => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const categories: Category[] = [
    'politics', 
    'business', 
    'technology', 
    'sports', 
    'entertainment', 
    'health', 
    'science'
  ];

  const currentDate = new Date().toLocaleDateString('en-GB', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md">
      {/* Top bar */}
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button 
            onClick={toggleSidebar} 
            className="lg:hidden p-2 rounded-md hover:bg-gray-100 transition-colors"
            aria-label="Toggle sidebar"
          >
            <Menu size={20} />
          </button>
          <div className="text-2xl font-serif font-bold text-[#0A2463]">InSight News</div>
        </div>
        
        <div className="hidden md:flex items-center text-sm text-gray-600">
          {currentDate}
        </div>
        
        <div className="flex items-center space-x-3">
          {isSearchOpen ? (
            <div className="flex items-center bg-gray-100 rounded-md px-2">
              <input
                type="text"
                placeholder="Search news..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent py-1 px-2 outline-none w-[200px]"
              />
              <button 
                onClick={() => setIsSearchOpen(false)} 
                className="p-1 text-gray-500 hover:text-gray-700"
              >
                <X size={16} />
              </button>
            </div>
          ) : (
            <button 
              onClick={() => setIsSearchOpen(true)} 
              className="p-2 rounded-md hover:bg-gray-100 transition-colors"
              aria-label="Search"
            >
              <Search size={20} />
            </button>
          )}
          
          <button 
            onClick={openLoginModal} 
            className="p-2 rounded-md hover:bg-gray-100 transition-colors flex items-center gap-1 text-sm"
            aria-label="Login"
          >
            <User size={18} />
            <span className="hidden md:inline">Login</span>
          </button>
        </div>
      </div>
      
      {/* Category navigation */}
      <CategoryNav categories={categories} />
    </header>
  );
};

export default Header;