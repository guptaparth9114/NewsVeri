import React from 'react';
import { Article, Category } from '../../types';
import NewsGrid from './NewsGrid';

interface CategoryNewsProps {
  categorizedArticles: Record<Category, Article[]>;
}

const CategoryNews: React.FC<CategoryNewsProps> = ({ categorizedArticles }) => {
  const categories = Object.keys(categorizedArticles) as Category[];
  
  return (
    <div className="space-y-6 py-6">
      {categories.map((category) => (
        <div key={category} id={category}>
          <NewsGrid 
            title={`${category.charAt(0).toUpperCase() + category.slice(1)}`}
            articles={categorizedArticles[category]}
          />
        </div>
      ))}
    </div>
  );
};

export default CategoryNews;