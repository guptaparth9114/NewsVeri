import React from 'react';
import { Article } from '../../types';
import SentimentBadge from './SentimentBadge';

interface NewsCardProps {
  article: Article;
  isFeatured?: boolean;
}

const NewsCard: React.FC<NewsCardProps> = ({ article, isFeatured = false }) => {
  return (
    <div className={`bg-white shadow-sm rounded-md overflow-hidden hover:shadow-md transition-shadow duration-300 
      ${isFeatured ? 'md:flex' : 'flex flex-col'}`}>
      <div className={`${isFeatured ? 'md:w-2/5' : 'w-full h-48'}`}>
        <img 
          src={article.imageUrl} 
          alt={article.title}
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className={`p-4 ${isFeatured ? 'md:w-3/5' : ''}`}>
        <div className="flex items-center space-x-2 mb-2">
          <span className="text-xs font-medium text-[#0A2463] bg-blue-100 px-2 py-0.5 rounded capitalize">
            {article.category}
          </span>
          <SentimentBadge sentiment={article.sentiment} />
          {article.isTrending && (
            <span className="text-xs font-medium text-amber-800 bg-amber-100 px-2 py-0.5 rounded">
              Trending
            </span>
          )}
        </div>
        
        <h3 className={`font-serif font-bold text-gray-900 mb-2 ${isFeatured ? 'text-xl' : 'text-lg'}`}>
          {article.title}
        </h3>
        
        <p className="text-gray-600 text-sm mb-3">
          {article.summary}
        </p>
        
        <div className="flex justify-between items-center text-xs text-gray-500">
          <span>{article.author}</span>
          <span>{article.date}</span>
        </div>
      </div>
    </div>
  );
};

export default NewsCard;