import React from 'react';

interface SentimentBadgeProps {
  sentiment: 'positive' | 'negative' | 'neutral';
  className?: string;
}

const SentimentBadge: React.FC<SentimentBadgeProps> = ({ sentiment, className = '' }) => {
  let bgColor = '';
  let textColor = '';
  let label = '';
  
  switch (sentiment) {
    case 'positive':
      bgColor = 'bg-green-100';
      textColor = 'text-green-800';
      label = 'Positive';
      break;
    case 'negative':
      bgColor = 'bg-red-100';
      textColor = 'text-red-800';
      label = 'Negative';
      break;
    case 'neutral':
      bgColor = 'bg-gray-100';
      textColor = 'text-gray-800';
      label = 'Neutral';
      break;
  }
  
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${bgColor} ${textColor} ${className}`}>
      {label}
    </span>
  );
};

export default SentimentBadge;