import React from 'react';
import { Article } from '../../types';
import NewsCard from './NewsCard';

interface TrendingNewsProps {
  articles: Article[];
}

const TrendingNews: React.FC<TrendingNewsProps> = ({ articles }) => {
  if (articles.length === 0) {
    return null;
  }

  // Use the first article as featured
  const featuredArticle = articles[0];
  // Use the rest as regular trending articles
  const trendingArticles = articles.slice(1);

  return (
    <section className="py-6 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-serif font-bold text-gray-900 mb-6 flex items-center">
          <span className="mr-2">Trending News</span>
          <span className="inline-block h-2 w-2 rounded-full bg-red-500 animate-pulse"></span>
        </h2>
        
        <div className="space-y-6">
          {/* Featured article */}
          <NewsCard article={featuredArticle} isFeatured={true} />
          
          {/* Other trending articles */}
          {trendingArticles.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {trendingArticles.map((article) => (
                <NewsCard key={article.id} article={article} />
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default TrendingNews;