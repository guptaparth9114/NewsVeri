import React, { useState, useEffect } from 'react';
import TrendingNews from '../components/News/TrendingNews';
import CategoryNews from '../components/News/CategoryNews';
import PaymentModal from '../components/Auth/PaymentModal';
import { Article, Category } from '../types';
import { articles, trendingArticles } from '../data/mockData';

const HomePage: React.FC = () => {
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [categorizedArticles, setCategorizedArticles] = useState<Record<Category, Article[]>>({} as Record<Category, Article[]>);
  
  useEffect(() => {
    // Group articles by category
    const grouped = articles.reduce((acc, article) => {
      if (!acc[article.category]) {
        acc[article.category] = [];
      }
      acc[article.category].push(article);
      return acc;
    }, {} as Record<Category, Article[]>);
    
    setCategorizedArticles(grouped);
  }, []);

  return (
    <div>
      <TrendingNews articles={trendingArticles} />
      
      <div className="container mx-auto px-4 py-6">
        <div className="bg-gradient-to-r from-[#0A2463] to-[#3E92CC] rounded-lg shadow-md p-6 mb-8">
          <div className="md:flex items-center justify-between">
            <div className="mb-4 md:mb-0 md:mr-6">
              <h3 className="text-xl md:text-2xl font-bold text-white mb-2">
                Unlock Premium Features
              </h3>
              <p className="text-blue-100 text-sm md:text-base">
                Get access to fake news detection, personalized news feed, and more.
              </p>
            </div>
            <button
              onClick={() => setIsPaymentModalOpen(true)}
              className="w-full md:w-auto bg-white text-[#0A2463] font-semibold py-2 px-6 rounded-md hover:bg-blue-50 transition-colors"
            >
              Subscribe Now
            </button>
          </div>
        </div>
        
        <CategoryNews categorizedArticles={categorizedArticles} />
      </div>
      
      {isPaymentModalOpen && (
        <PaymentModal onClose={() => setIsPaymentModalOpen(false)} />
      )}
    </div>
  );
};

export default HomePage;