export interface Article {
  id: string;
  title: string;
  summary: string;
  content: string;
  author: string;
  date: string;
  category: Category;
  imageUrl: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  isTrending: boolean;
}

export type Category = 'politics' | 'business' | 'technology' | 'sports' | 'entertainment' | 'health' | 'science';

export interface User {
  id: string;
  name: string;
  email: string;
  isPremium: boolean;
}